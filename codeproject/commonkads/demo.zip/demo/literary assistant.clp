;;;======================================================
;;; Literary assistant
;;;
;;; Code and original idea by Carlos Jim�nez de Parga (c)
;;;
;;; To execute, merely load, reset, and run.
;;;    
;;;======================================================

;;;***************************
;;;* DEFTEMPLATE DEFINITIONS *
;;;***************************

; Concept person

(deftemplate person
	(slot name (type STRING))
	(slot age (type INTEGER))
	(slot stage (type SYMBOL))
	(multislot interests (type SYMBOL))
	(slot education (type SYMBOL)))

; Concept reading-type

(deftemplate reading-type
	(slot genre (type SYMBOL)))

; Concept reader-type

(deftemplate reader-type
	(slot level (type SYMBOL)))
	
; Concept book

(deftemplate book
	(slot title (type STRING)))	

; Age range structure
	
(deftemplate range
	(slot low (type INTEGER))
	(slot high (type INTEGER))
	(slot stage (type SYMBOL))
)	

; Level table structure

(deftemplate level
	(slot education (type SYMBOL))
	(slot stage (type SYMBOL))
	(slot level (type SYMBOL))
)	
	
; Suggested book table structure

(deftemplate category
	(slot level (type SYMBOL))
	(slot genre (type SYMBOL))
	(slot book 	(type STRING))
)
	
; Suggested genre structure

(deftemplate matter
	(multislot interest (type SYMBOL))
	(slot genre (type SYMBOL))
)	



;;;***************************
;;;* INITIAL FACTS DEFINITION *
;;;***************************


; List of interests
	
(deffacts data
		(area Music Painting Movies Sculpture Theater Poetry Novel Tales Biology Physics Chemistry Maths Logic
	     Ethics Politics Metaphysics History Biographies Archeology Computers Design Construction Electronics Mechanics)
)

; Age range table

(deffacts abstract_age
	(range (low 0)(high 13)(stage CHILD))
	(range (low 14)(high 19)(stage TEENAGER))
	(range (low 20)(high 35)(stage YOUNG))
	(range (low 36)(high 9999)(stage ADULT))
)

; Suggested genre table

(deffacts suggested_genre
	(matter (interest Music Painting Movies Sculpture)(genre ART))
	(matter (interest Theater Poetry Novel Tales)(genre LITERATURE))
	(matter (interest Biology Physics Chemistry Maths)(genre SCIENCE))
	(matter (interest Logic Ethics Politics Metaphysics)(genre PHILOSOPHY))
	(matter (interest History Biographies Archeology)(genre HISTORY))
	(matter (interest Computers Design Construction Electronics Mechanics)(genre TECHNOLOGY))
)	

; Suggested level table

(deffacts suggested_level
	(level (education GRAMMAR_SCHOOL)(stage CHILD)(level CHILD))
	(level (education SCHOOL)(stage CHILD)(level BASIC))
	(level (education SCHOOL)(stage TEENAGER)(level BASIC))
	(level (education SCHOOL)(stage YOUNG)(level BASIC))
	(level (education SCHOOL)(stage ADULT)(level INTERMEDIATE))
	(level (education SECONDARY)(stage TEENAGER)(level INTERMEDIATE))
	(level (education SECONDARY)(stage YOUNG)(level ADVANCED))
	(level (education SECONDARY)(stage ADULT)(level ADVANCED))
	(level (education UNIVERSITY)(stage TEENAGER)(level ADVANCED))
	(level (education UNIVERSITY)(stage YOUNG)(level ADVANCED))
	(level (education UNIVERSITY)(stage ADULT)(level ADVANCED))
)	

; Suggested books table

(deffacts suggested_books
	(category (level CHILD)(genre ART)(book "Masterpiece colouring"))
	(category (level BASIC)(genre ART)(book "Introduction to Arts"))
	(category (level INTERMEDIATE)(genre ART)(book "World-class artworks"))
	(category (level ADVANCED)(genre ART)(book "Encyclopedia of Art"))
	
	(category (level CHILD)(genre LITERATURE)(book "The Little Prince"))
	(category (level BASIC)(genre LITERATURE)(book "The Three Musketeers"))
	(category (level INTERMEDIATE)(genre LITERATURE)(book "Oliver Twist"))
	(category (level ADVANCED)(genre LITERATURE)(book "Don Quixote"))
	
	(category (level CHILD)(genre SCIENCE)(book "Arithmetics handouts"))
	(category (level BASIC)(genre SCIENCE)(book "Basic arithmetics and geometry"))
	(category (level INTERMEDIATE)(genre SCIENCE)(book "Derivatives and integrals"))
	(category (level ADVANCED)(genre SCIENCE)(book "Differential equations"))
	
	(category (level CHILD)(genre PHILOSOPHY)(book "Philosophy for childrens"))
	(category (level BASIC)(genre PHILOSOPHY)(book "The World of Sofia"))
	(category (level INTERMEDIATE)(genre PHILOSOPHY)(book "Philosophy in Ancient Greece"))
	(category (level ADVANCED)(genre PHILOSOPHY)(book "Descartes' philosophy"))
	
	(category (level CHILD)(genre HISTORY)(book "History for childrens"))
	(category (level BASIC)(genre HISTORY)(book "Introduction to history"))
	(category (level INTERMEDIATE)(genre HISTORY)(book "History of the Roman Empire"))
	(category (level ADVANCED)(genre HISTORY)(book "Encyclopedia of History"))
	
	(category (level CHILD)(genre TECHNOLOGY)(book "Build your own toy"))
	(category (level BASIC)(genre TECHNOLOGY)(book "Introduction to technology"))
	(category (level INTERMEDIATE)(genre TECHNOLOGY)(book "Technological design"))
	(category (level ADVANCED)(genre TECHNOLOGY)(book "Machine physics"))
)	

; Interests menu

(deffunction print_interests ($?styles)
	(bind ?i 0)(bind ?t 1)
	(while (neq ?i 6) do
		(bind ?j 0)
		(while (neq ?j 4) do
			(bind ?d (nth$ ?t $?styles))
			(printout t ?t". " ?d)
			(if (< ?t 10) then (bind ?distance 1) else (bind ?distance 0))
			(bind ?distance (+ ?distance (- 15 (length$ ?d)))) 
			(bind ?r 1)
			(while (< ?r ?distance) do
				(printout t " ")
				(bind ?r (+ ?r 1))
			)	
			(bind ?t (+ ?t 1))
			(bind ?j (+ ?j 1))
		)
	(printout t crlf)
	(bind ?i (+ ?i 1))
	)
)

; Check for correct number

(deffunction checknumber (?n ?lr ?hr)
	(if (and (>= ?n ?lr)(<= ?n ?hr)) then (return TRUE)
	else (printout t "Incorrect input. Try a number between " ?lr " and " ?hr crlf crlf)
		 (return FALSE)
	)
)	

;;;**************************
;;;* 		RULES 		    *
;;;**************************


; Entry point. Query the user for data input
	
(defrule get_data
	?f1<-(initial-fact)
	(area $?styles)
	=>
	(printout t "*What is your name?: ")
	(bind ?name (readline))
	(printout t "*How old are you?: ")
	(bind ?age (read-number))
	(printout t "*What are your interests?: " crlf)
	(bind ?number 10)	
	(bind ?x 1)
	(bind $?interests (create$))
	(while (neq ?number 0) do 
		(print_interests $?styles)
		(printout t crlf)
		(printout t "0. Exit" crlf)
		(printout t "----------------------------------------------------------------------------" crlf)
		(printout t "Other interests? (No = Type  0; Yes = Type 1 - 24)" crlf)
		(bind ?number (read-number))
		(checknumber ?number 0 24)
		(if (and (> ?number 0)(< ?number 25)) then 
			(bind ?cat (nth$ ?number $?styles))
			(if (eq (member$ ?cat $?interests) FALSE) then
				(bind $?interests (insert$ $?interests ?x ?cat))
				(bind ?x (+ ?x 1))
			)
		) 
	)
	(bind ?number 0)
	(while (or (< ?number 1)(> ?number 4)) 
		(printout t "*What is your education?: " crlf)
		(printout t "1. Grammar school      2. School      3. Secondary      4. University" crlf)
		(bind ?number (read-number))
		(checknumber ?number 1 4)
	)	

	;(bind ?education SCHOOL)
	(switch ?number
		(case  1 then (bind ?education GRAMMAR_SCHOOL))
		(case  2 then (bind ?education SCHOOL))
		(case  3 then (bind ?education SECONDARY))
		(case  4 then (bind ?education UNIVERSITY))
	)	
	
	(assert (person (name ?name)(age ?age)(interests $?interests)(education ?education)))
	(retract ?f1)
	(assert (abstract))
)

; Abstract age

(defrule abstract_age
	?f1<-(abstract)
	?f2<-(person (age ?age))
	(range (low ?l)(high ?h)(stage ?s))
	(test (and (>= ?age ?l)(<= ?age ?h)))
	=>
	(modify ?f2 (stage ?s))
	(retract ?f1)
	(assert (interests))
	(assert (start_level))
)	

; Select level according to education

(defrule select_level
	?f1<-(start_level)
	(person (education ?edu)(stage ?stg))
	(level (education ?edu)(stage ?stg)(level ?lev))
	=>
	(assert (reader-type (level ?lev)))
	(retract ?f1)
)	

; Find interests in interest list
		
(deffunction has_person (?mat $?interests)
	(return (member$ ?mat $?interests))
)	
		
; Select genres according to interests
		
(defrule select_genre
	(interests)
	(person (interests $?interests))
	(matter (interest $?cat)(genre ?genre))
	=>
	(bind ?i 1)
	(while (<= ?i (length$ $?interests))
		(bind ?mat (nth$ ?i $?interests))
		(if (has_person ?mat $?cat) then
			(assert (reading-type (genre ?genre)))
		)
	(bind ?i (+ ?i 1))	
	)
)	
			
; Select books according to interests 

(defrule select_book
	(reader-type (level ?level))
	(reading-type (genre ?genre))
	(category (level ?level)(genre ?genre)(book ?book))
	=>
	(printout t "According to this data, you should read: " ?book crlf)
)	


	