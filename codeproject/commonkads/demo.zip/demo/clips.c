// clips.cpp : Defines the entry point for the console application.
//

#include <iostream>

extern "C"
{
	#include "clips.h"	
}

using namespace std;

int main(int argc, char* argv[])
{
	InitializeEnvironment();
	Load("literary assistant.clp");
	Reset();
	Run(-1L);
	cin.get();
	return 0;
}